<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>InnovTrade - Autókölcsönző</title>
  <?php
  // Foglalt autók kigyűjtése JavaScript változóba
  $foglaltAutok = [];
  $eredmeny = $kapcsolat->query("SELECT f.datum, fa.auto_nev FROM foglalasok f JOIN foglalas_autok fa ON f.id = fa.foglalas_id");
  if ($eredmeny && $eredmeny->num_rows > 0) {
      while ($sor = $eredmeny->fetch_assoc()) {
          $datum = $sor['datum'];
          $auto = $sor['auto_nev'];
          if (!isset($foglaltAutok[$auto]) || strtotime($datum) > strtotime($foglaltAutok[$auto])) {
              $foglaltAutok[$auto] = $datum;
          }
      }
  }
  ?>
  <script>
    window.foglaltAutok = <?php echo json_encode($foglaltAutok, JSON_UNESCAPED_UNICODE); ?>;
    document.addEventListener("DOMContentLoaded", function () {
      megjelenitResz('kezdolap');
      kategoriaMegjelenites('osszes');
    });
  </script>
  <link rel="stylesheet" href="vizsga.css">
  <script src="vizsga.js" defer></script>
  <style>
    .dropdown {
      position: relative;
      display: inline-block;
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background-color: #dddddd;
      min-width: 200px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.2);
      z-index: 1;
      border-radius: 5px;
    }
    .dropdown-menu a {
      color: #000;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }
    .dropdown-menu a:hover {
      background-color: #ff0000;
    }
    .dropdown:hover .dropdown-menu {
      display: block;
    }
    #regisztracio, #belepes {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 90%;
      max-width: 400px;
      background-color: #fff;
      padding: 20px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      border-radius: 10px;
      z-index: 1000;
      display: none;
    }
    #felhasznalo-info {
      position: fixed;
      top: 10px;
      right: 10px;
      background-color: #2a9d8f;
      color: #fff;
      padding: 5px 10px;
      border-radius: 5px;
      font-size: 0.9rem;
    }
    #felhasznalo-info a {
      color: #fff;
      text-decoration: none;
      margin-left: 10px;
    }
    section:not(#kezdolap):not(#autok) {
      display: none;
    }
  </style>
</head>
<body>
  <header>
    <div class="header-container">
      <img src="kepek/logo.png" alt="InnovTrade Logó" class="logo">
      <h1>InnovTrade - Autókölcsönző</h1>
    </div>
    <p class="header-description">Minőségi autók minden kategóriában. Találd meg az igazit!</p>
    <nav>
      <ul>
        <li><a href="#kezdolap" onclick="megjelenitResz('kezdolap')">Kezdőlap</a></li>
        <li class="dropdown">
          <a href="#autok">Autók ▼</a>
          <div class="dropdown-menu">
              <a href="#osszes" onclick="kategoriaMegjelenites('osszes')">Összes</a>
              <a href="#gazdasagos" onclick="kategoriaMegjelenites('gazdasagos')">Gazdaságos</a>
              <a href="#csaladi" onclick="kategoriaMegjelenites('csaladi')">Családi</a>
              <a href="#luxus" onclick="kategoriaMegjelenites('luxus')">Luxus</a>
              <a href="#sport" onclick="kategoriaMegjelenites('sport')">Sport</a>

          </div>
        </li>
        <li><a href="#foglalas" onclick="megjelenitResz('foglalas')">Foglalás</a></li>
        <li><a href="#kapcsolat" onclick="megjelenitResz('kapcsolat')">Kapcsolat</a></li>
        <li><a href="#velemenyek" onclick="megjelenitResz('velemenyek')">Vélemények</a></li>
      </ul>
    </nav>
  </header>
  <script>
    function megjelenitResz(reszId) {
      document.querySelectorAll("main section").forEach(section => {
        section.style.display = "none";
      });
      const szekcio = document.getElementById(reszId);
      if (szekcio) szekcio.style.display = "block";
    }
  </script>

</header>


  
  <div id="felhasznalo-info">
    <?php if(isset($_SESSION['felhasznalo'])): ?>
        <span>Bejelentkezve: <?php echo htmlspecialchars($_SESSION['felhasznalo']); ?></span>
        <a href="kijelentkezes.php" title="Kijelentkezés">
            <img src="kepek/logout_icon.png" alt="Kijelentkezés" style="width:25px; vertical-align:middle;">
        </a>
    <?php else: ?>
        <a href="#" id="belepes-gomb">Bejelentkezés</a> |
        <a href="#" id="regisztracio-gomb">Regisztráció</a>
    <?php endif; ?>
</div>


  
  <!-- Regisztráció és Belépés gombok (ha nincs bejelentkezve) -->
  <?php if(!isset($_SESSION['felhasznalo'])): ?>
  <?php endif; ?>
  
  <div id="overlay"></div>
  
  <!-- Regisztrációs űrlap -->
  <section id="regisztracio">
    <h2>Regisztráció</h2>
    <form id="regisztracio-urlap" action="regisztracio.php" method="POST">
      <label for="felhasznalonev">Felhasználónév:</label>
      <input type="text" id="felhasznalonev" name="felhasznalonev" required placeholder="Írd be a felhasználóneved">
      <label for="email">Email cím:</label>
      <input type="email" id="email" name="email" required placeholder="Írd be az email címed">
      <label for="jelszo">Jelszó:</label>
      <input type="password" id="jelszo" name="jelszo" required placeholder="Írd be a jelszavad">
      <label for="jelszo_megerositese">Jelszó megerősítése:</label>
      <input type="password" id="jelszo_megerositese" name="jelszo_megerositese" required placeholder="Erősítsd meg a jelszavad">
      <button type="submit">Regisztrálok</button>
    </form>
    <button class="bezaras-gomb" onclick="zarasFelulet()">Bezárás</button>
  </section>
  
  <!-- Belépési űrlap -->
  <section id="belepes">
    <h2>Belépés</h2>
    <form id="belepes-urlap" action="bejelentkezes.php" method="POST">
      <label for="felhasznalonev">Felhasználónév:</label>
      <input type="text" id="felhasznalonev_reg" name="felhasznalonev" required placeholder="Írd be a felhasználóneved">
      <label for="jelszo">Jelszó:</label>
      <input type="password" id="jelszo_reg" name="jelszo" required placeholder="Írd be a jelszavad">
      <button type="submit">Belépek</button>
    </form>
    <button class="bezaras-gomb" onclick="zarasFelulet()">Bezárás</button>
  </section>
  
  <main>
    
  <section id="kezdolap" style="padding: 60px 30px; background-color: #f9fcff;">
  <div style="display: flex; flex-wrap: wrap; max-width: 1400px; margin: auto; align-items: center; gap: 40px;">

    <!-- Bal oldali kép -->
    <div style="flex: 1 1 500px;">
      <img src="kepek/hegyi_auto.jpg" alt="Autó a hegyek között"
           style="width: 100%; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.2);">
    </div>

    <!-- Jobb oldali szövegek + gomb + slider vélemények -->
    <div style="flex: 1 1 600px; color: #111;">
      <h2 style="font-size: 2.7rem; color: #0077cc;">Fedezd fel a vezetés élményét</h2>
      <p style="font-size: 1.15rem; line-height: 1.8;">
        Az InnovTrade a megbízhatóság, rugalmasság és élmény vezetője. Akár a városban, akár a természetben jársz, nálunk mindig megtalálod a hozzád illő járművet.
      </p>
      <p style="font-size: 1.15rem;">
        Modern flottánk és villámgyors foglalási rendszerünk lehetővé teszi, hogy gondtalanul elindulj – bármikor, bárhová.
      </p>
      <p style="font-size: 1.15rem;">
        Indulj velünk, és tapasztald meg az autóbérlés új szintjét: egyszerű, átlátható, megbízható.
      </p>
      <div style="margin-top: 30px;">
        <a href="#autok" onclick="megjelenitResz('autok')" style="display: inline-block; background-color: #0077cc; color: white; padding: 14px 28px; border-radius: 8px; font-size: 1.1rem; text-decoration: none;">🚗 Nézd meg autóinkat</a>
      </div>

      <!-- Vélemény slider -->
      <div style="margin-top: 40px; overflow-x: auto; display: flex; gap: 20px; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch;">
        <div style="flex: 0 0 300px; scroll-snap-align: center; background: rgba(0,0,0,0.06); padding: 20px; border-radius: 10px;">
          <p style="font-style: italic;">„Tökéletes bérlési élmény, azonnal indulhattunk.”</p>
          <p style="font-weight: bold;">– Dóra</p>
        </div>
        <div style="flex: 0 0 300px; scroll-snap-align: center; background: rgba(0,0,0,0.06); padding: 20px; border-radius: 10px;">
          <p style="font-style: italic;">„Nagyon kényelmes, gyors, ajánlom mindenkinek.”</p>
          <p style="font-weight: bold;">– Gergő</p>
        </div>
        <div style="flex: 0 0 300px; scroll-snap-align: center; background: rgba(0,0,0,0.06); padding: 20px; border-radius: 10px;">
          <p style="font-style: italic;">„A természetbe vágytunk – és el is jutottunk!”</p>
          <p style="font-weight: bold;">– Petra</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Hogyan működik? szekció külön, teljesen biztosan jól elhelyezve -->
<section id="hogyan-mukodik" style="padding: 80px 20px; background: linear-gradient(to right, #f3faff, #e6f0ff); display: block;">
  <div style="max-width: 1100px; margin: auto; text-align: center;">
    <h2 style="font-size: 2.5rem; color: #0077cc; margin-bottom: 20px;">Hogyan működik?</h2>
    <p style="font-size: 1.2rem; color: #444; max-width: 700px; margin: 0 auto 50px;">
      Három lépés és már úton is vagy! Nincs papírmunka, nincs felesleges várakozás.
    </p>

    <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 30px;">
      <div style="flex: 1 1 280px; background: white; border-radius: 12px; padding: 30px 20px; box-shadow: 0 8px 20px rgba(0,0,0,0.08);">
        <div style="font-size: 2.5rem; color: #0077cc;">🔍</div>
        <h3 style="margin-top: 15px;">1. Böngéssz</h3>
        <p style="color: #333;">Nézd meg autóinkat, válassz kategóriát, állítsd be a napok számát.</p>
      </div>
      <div style="flex: 1 1 280px; background: white; border-radius: 12px; padding: 30px 20px; box-shadow: 0 8px 20px rgba(0,0,0,0.08);">
        <div style="font-size: 2.5rem; color: #0077cc;">📝</div>
        <h3 style="margin-top: 15px;">2. Foglalj</h3>
        <p style="color: #333;">Add meg az adataidat, válassz fizetési módot, és erősítsd meg.</p>
      </div>
      <div style="flex: 1 1 280px; background: white; border-radius: 12px; padding: 30px 20px; box-shadow: 0 8px 20px rgba(0,0,0,0.08);">
        <div style="font-size: 2.5rem; color: #0077cc;">🚗</div>
        <h3 style="margin-top: 15px;">3. Indulj</h3>
        <p style="color: #333;">Vedd át az autót, és élvezd az utazást, mi minden mást intézünk.</p>
      </div>
    </div>
  </div>
</section>
<!-- Keresés és szűrés sáv -->
<div style="display: flex; flex-wrap: wrap; gap: 15px; justify-content: center; align-items: center; margin: 40px auto; max-width: 1000px; padding: 20px; background: #f2f6fc; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
<label style="display: flex; align-items: center; gap: 5px; font-size: 0.95rem;">
  <input type="checkbox" id="csak-elerheto" style="transform: scale(1.2);"> Csak elérhető autók
</label>

  <input type="text" id="auto-kereso" placeholder="🔍 Keresés név vagy márka alapján..." style="flex: 1 1 250px; padding: 10px 14px; font-size: 1rem; border-radius: 6px; border: 1px solid #ccc;">
  
  <select id="rendezes" style="flex: 1 1 200px; padding: 10px 14px; font-size: 1rem; border-radius: 6px; border: 1px solid #ccc;">
  <option value="ar_novekvo">Ár szerint növekvő</option>
<option value="ar_csokkeno">Ár szerint csökkenő</option>
<option value="nev_az">Név szerint (A-Z)</option>
<option value="nev_za">Név szerint (Z-A)</option>

  </select>
</div>

  
    <!-- Foglalás űrlap -->
    <section id="foglalas">
      <h2>Foglalás</h2>
      <div id="kosar-tartalom">
        <h3>Kosár tartalma</h3>
        <ul id="kosar-lista">
            <?php
            if (isset($_SESSION['kosar']) && count($_SESSION['kosar']) > 0) {
            foreach ($_SESSION['kosar'] as $auto) {
                echo "<li>" . htmlspecialchars($auto['nev']) . " - " . htmlspecialchars($auto['ar']) . " Ft/nap</li>";
            }
            } else {
                echo "<li>A kosár üres.</li>";
            }
            ?>
        </ul>
       


      </div>
      <form id="foglalas-urlap" action="foglalas.php" method="POST">
        <!-- Rejtett mező, amelybe a kosárból automatikusan beíródnak az autók nevei -->
        <input type="hidden" id="foglalas-autonev-hidden" name="autonev">
    
        <label for="foglalas-datum">Foglalás dátuma:</label>
        <input type="date" id="foglalas-datum" name="datum" required>
        
        <label for="foglalas-nev">Név:</label>
        <input type="text" id="foglalas-nev" name="nev" required value="<?php echo isset($_SESSION['felhasznalo']) ? htmlspecialchars($_SESSION['felhasznalo']) : ''; ?>" readonly>

        <label for="foglalas-email">Email:</label>
        <input type="email" id="foglalas-email" name="email" required value="<?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : ''; ?>" readonly>
    
        <label for="foglalas-email">Email:</label>
        <input type="email" id="foglalas-email-2" name="email" required value="<?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : ''; ?>">

        <button type="submit">Foglalás küldése</button>
      </form>
      <div id="vegosszeg-kijelzes" style="
    margin-top: 12px;
    padding: 12px 20px;
    background: linear-gradient(90deg, #dff0d8, #c8e5bc);
    border: 1px solid #b2d8a8;
    border-radius: 8px;
    font-weight: bold;
    font-size: 1.1rem;
    color: #2d572c;
    text-align: left;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    ">
    Végösszeg: <span id="osszegErtek">0 Ft</span>
    </div>
    </section>
   
    <?php
if (isset($_SESSION['szamla_elkeszult']) && isset($_SESSION['szamla_fajl']) && file_exists($_SESSION['szamla_fajl']))
{
    echo '<div style="text-align: center; margin-top: 20px;">
            <a href="szamla_megjelenites.php" class="stilusos-gomb">Számla megtekintése</a>
          </div>';
}
?>

<section style="padding: 3rem 2rem; background-color: #fffaf3;">
  <div style="max-width: 1000px; margin: 0 auto;">
    <h2 style="text-align: center; color: #cc6600;">Mit mondanak rólunk?</h2>
    <p style="text-align: center; font-size: 1.1rem; max-width: 700px; margin: 1rem auto;">
      Ügyfeleink élményei motiválnak minket nap mint nap. Íme néhány visszajelzés azok közül, akik már megtapasztalták az InnovTrade megbízhatóságát.
    </p>

    <div style="display: flex; flex-wrap: wrap; gap: 2rem; justify-content: center; margin-top: 2rem;">

      <div style="flex: 1 1 280px; background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="font-style: italic;">„Gyors foglalás, tiszta autó, korrekt ár. Ennél nem is kell több.”</p>
        <p style="text-align: right; font-weight: bold;">– M. Dániel</p>
      </div>

      <div style="flex: 1 1 280px; background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="font-style: italic;">„Hétvégén kellett volna autó, és még aznap megkaptam. Profi rendszer.”</p>
        <p style="text-align: right; font-weight: bold;">– L. Ágnes</p>
      </div>

      <div style="flex: 1 1 280px; background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="font-style: italic;">„Imádtam a sportautókat! Végre egy hely, ahol elérhetők is.”</p>
        <p style="text-align: right; font-weight: bold;">– B. Andor</p>
      </div>

    </div>
  </div>
</section>

    <!-- Vélemények -->
     <!-- Látványos véleményszekció – ezt ILLESZD a <section id="velemenyek"> ELÉ -->
<section style="padding: 3rem 2rem; background-color: #fffaf3;">
  <div style="max-width: 1000px; margin: 0 auto;">
    <h2 style="text-align: center; color: #cc6600;">Mit mondanak rólunk?</h2>
    <p style="text-align: center; font-size: 1.1rem; max-width: 700px; margin: 1rem auto;">
      Ügyfeleink élményei motiválnak minket nap mint nap. Íme néhány visszajelzés azok közül, akik már megtapasztalták az InnovTrade megbízhatóságát.
    </p>

    <div style="display: flex; flex-wrap: wrap; gap: 2rem; justify-content: center; margin-top: 2rem;">

      <div class="velemeny-doboz" style="flex: 1 1 280px; background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="font-style: italic;">„Gyors foglalás, tiszta autó, korrekt ár. Ennél nem is kell több.”</p>
        <p style="text-align: right; font-weight: bold;">– M. Dániel</p>
      </div>

      <div class="velemeny-doboz" style="flex: 1 1 280px; background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="font-style: italic;">„Hétvégén kellett volna autó, és még aznap megkaptam. Profi rendszer.”</p>
        <p style="text-align: right; font-weight: bold;">– L. Ágnes</p>
      </div>

      <div class="velemeny-doboz" style="flex: 1 1 280px; background: #fff; padding: 1.5rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="font-style: italic;">„Imádtam a sportautókat! Végre egy hely, ahol elérhetők is.”</p>
        <p style="text-align: right; font-weight: bold;">– B. Andor</p>
      </div>

    </div>
  </div>
</section>

    <section id="velemenyek">
      <h2>Vásárlói Vélemények</h2>
      
      <div id="velemenyek-lista">
        <?php
          $sqlVelemenyek = "SELECT v.auto_nev, v.szoveg, f.felhasznalonev 
                             FROM velemenyek v 
                             JOIN felhasznalok f ON v.felhasznalo_id = f.id 
                             ORDER BY v.letrehozas_datum DESC";
          $eredmenyVelemenyek = $kapcsolat->query($sqlVelemenyek);
          if ($eredmenyVelemenyek && $eredmenyVelemenyek->num_rows > 0) {
            while ($sor = $eredmenyVelemenyek->fetch_assoc()) {
              echo "<p><strong>" . htmlspecialchars($sor['felhasznalonev']) . " (" . htmlspecialchars($sor['auto_nev']) . "):</strong> " . htmlspecialchars($sor['szoveg']) . "</p>";
            }
          } else {
            echo "<p>Még nincs vélemény. Légy te az első!</p>";
          }
        ?>
      </div>
      <form id="velemeny-urlap">
        <label for="velemeny-autonev">Autó neve:</label>
        <input type="text" id="velemeny-autonev" placeholder="Pl.: Fiat 500" required>
        <label for="velemeny-szoveg">Véleményed:</label>
        <textarea id="velemeny-szoveg" rows="4" placeholder="Írd meg a véleményed!" required></textarea>
        <button type="button" onclick="velemenyHozzaadasa()">Vélemény Beküldése</button>
      </form>
    </section>

    
    <!-- Kapcsolat -->
    <section id="kapcsolat">
      <h2>Kapcsolat</h2>
      <p>Ügyfélszolgálatunk 0-24 elérhető</p>
      <form id="kapcsolat-urlap">
        <label for="kapcsolat-nev">Név:</label>
        <input type="text" id="kapcsolat-nev" required value="<?php echo isset($_SESSION['felhasznalo']) ? htmlspecialchars($_SESSION['felhasznalo']) : ''; ?>">
        <label for="kapcsolat-email">Email:</label>
        <input type="email" id="kapcsolat-email" required value="<?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : ''; ?>">
        <label for="kapcsolat-uzenet">Üzenet:</label>
        <textarea id="kapcsolat-uzenet" rows="5" required></textarea>
        <button type="button" onclick="kapcsolatHozzaadasa()">Üzenet Küldése</button>
      </form>
    </section>
  



<div class="autok-halo" id="autok-halo">
<?php
$kapcsolat = new mysqli("localhost", "root", "", "innovtrade");
if ($kapcsolat->connect_error) {
    die("Sikertelen adatbáziskapcsolat: " . $kapcsolat->connect_error);
}

$lekerdezes = "SELECT * FROM autok";
$eredmeny = $kapcsolat->query($lekerdezes);

if ($eredmeny && $eredmeny->num_rows > 0) {
    while ($auto = $eredmeny->fetch_assoc()) {
        $kategoriaklassz = strtolower($auto['kategoria']);
        echo "<div class='auto $kategoriaklassz' data-ar='" . (int)$auto['ar'] . "'>";
        echo "<img src='kepek/{$auto['kep']}' alt='{$auto['nev']}' style='width:100%; height:auto;'>";
        echo "<h3>" . htmlspecialchars($auto['nev']) . "</h3>";
        echo "<p>" . htmlspecialchars($auto['kategoria']) . "</p>";
        echo "<p class='auto-ar'>" . htmlspecialchars($auto['ar']) . " Ft/nap</p>";
        echo "<button onclick=\"hozzaadKosarhoz('" . htmlspecialchars($auto['nev']) . "', " . (int)$auto['ar'] . ")\">Kosárba</button>";
        echo "</div>";
    }
} else {
    echo "<p>Nincs elérhető autó az adatbázisban.</p>";
}
?>
</div>


<script>
document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("auto-kereso");
  const select = document.getElementById("rendezes");
  const container = document.getElementById("autok-halo");

  function szurEsRendez() {
    const query = searchInput.value.toLowerCase();
    let elemek = Array.from(container.getElementsByClassName('auto'));

    // Szűrés
    elemek.forEach(elem => {
      const text = elem.textContent.toLowerCase();
      elem.style.display = text.includes(query) ? 'inline-block' : 'none';
    });

    // Rendezés
    elemek = elemek.filter(e => e.style.display !== 'none');
    const sorrend = select.value;

    if (sorrend === 'ar_novekvo') {
      elemek.sort((a, b) => parseInt(a.dataset.ar) - parseInt(b.dataset.ar));
    } else if (sorrend === 'ar_csokkeno') {
      elemek.sort((a, b) => parseInt(b.dataset.ar) - parseInt(a.dataset.ar));
    } else if (sorrend === 'nev_az') {
      elemek.sort((a, b) => a.textContent.localeCompare(b.textContent));
    } else if (sorrend === 'nev_za') {
      elemek.sort((a, b) => b.textContent.localeCompare(a.textContent));
    }

    // Újrarendezés
    elemek.forEach(elem => container.appendChild(elem));
  }

  searchInput.addEventListener('input', szurEsRendez);
  select.addEventListener('change', szurEsRendez);
});

</script>

</main>
  
  <footer>
        <p2>&copy; 2024 InnovTrade Autókölcsönző. Minden jog fenntartva.</p2>
        <p>Fedezz fel minket Instagramon és Facebookon!</p>
        <a href="https://www.instagram.com/innov_trade" target="_blank">
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="Instagram" width="40" height="40">
        
            <a href="https://www.facebook.com/yourusername" target="_blank">
          <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook" width="40" height="40">
        </a>
    </footer>
     
  <?php
      if (!isset($_SESSION['kosar'])) {
          $_SESSION['kosar'] = []; // Ha még nincs kosár, inicializáljuk
      }
    // Visszajelzés URL paraméterek alapján
    if (isset($_GET['regisztracio']) && $_GET['regisztracio'] == 1) {
      echo "<p style='text-align:center; color:green;'>Sikeres regisztráció!</p>";
    }
    if (isset($_GET['bejelentkezes']) && $_GET['bejelentkezes'] == 1) {
      echo "<p style='text-align:center; color:green;'>Sikeres bejelentkezés!</p>";
    }
    if (isset($_GET['kijelentkezes']) && $_GET['kijelentkezes'] == 1) {
      echo "<p style='text-align:center; color:green;'>Sikeres kijelentkezés!</p>";
    }
  ?>

<section id="kosar-szekcio" style="margin-top: 40px; padding: 20px;">
  <h2 style="text-align:center;">🛒 Kosár tartalma</h2>
  <ul id="kosar-lista" style="list-style-type: none; padding: 0;"></ul>
  <input type="hidden" id="foglalas-autonev-hidden" name="autonev">
</section>
<div id="also-kosar">
  <h3>🛒 Kosár</h3>
  <!-- ide tölt be dinamikusan a kosar_panel.php -->
</div>

<script>
function frissitKosarat() {
    fetch("kosar_panel.php")
        .then(valasz => valasz.text())
        .then(tartalom => {
            document.getElementById("also-kosar").innerHTML = tartalom;

            // Gombok újraaktiválása – most már biztosan
            setTimeout(() => {
                document.querySelectorAll(".also-torles").forEach(gomb => {
                    gomb.addEventListener("click", function () {
                        const index = this.getAttribute("data-index");
                        fetch("torles_kosarbol.php", {
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            body: "index=" + encodeURIComponent(index)
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.siker) {
                                sessionStorage.setItem("kosar", JSON.stringify(data.kosar));
                                frissitKosarat();
                                frissitKosar(); // foglalási panel
                            }
                        });
                    });
                });
            }, 50); // kis várakozás a DOM beillesztés után
        });
}

window.addEventListener("load", frissitKosarat);
</script>

<button onclick="manualKosar()">Teszt Kosárba (Audi R8, 3 nap)</button>

<script>
function manualKosar() {
    fetch("kosar_hozaadasa.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "autonev=Audi R8&napok=3"
    }).then(response => response.json())
    .then(data => {
        alert("Kosárba rakás teszt: " + (data.siker ? "Sikeres!" : "Sikertelen!"));
        frissitKosarat();
    });
}
<button id="kosar-toggle">Kosár 🛒</button>

const toggleGomb = document.getElementById("kosar-toggle");
const kosarPanel = document.getElementById("also-kosar");

toggleGomb.addEventListener("click", () => {
  kosarPanel.classList.toggle("rejtett");
});


</script>


</body>
</html>