<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $index = (int)($_POST['index'] ?? -1);
    if (isset($_SESSION['kosar'][$index])) {
        array_splice($_SESSION['kosar'], $index, 1);
    }

    header('Content-Type: application/json');
    echo json_encode([
        'siker' => true,
        'kosar' => $_SESSION['kosar']
    ]);
}
?>
