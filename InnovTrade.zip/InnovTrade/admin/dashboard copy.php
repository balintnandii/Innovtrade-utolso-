<?php
session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

// Kilépés kezelése
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$menupont = 1;
if (isset($_GET['m']) && is_numeric($_GET['m'])) {
    $menupont = intval($_GET['m']);
}

// Menü definíció
$menu = [
    ["id" => 1, "nev" => "uj_felh", "title" => "Felhasználó"],
    ["id" => 2, "nev" => "Jarmuvek", "title" => "Jármű lista"],
    ["id" => 3, "nev" => "Eladasok", "title" => "Eladások"]
];

// Tartalom definíció
$tartalom = [
    ["menu_id" => 1, "cim" => "Új felhasználó", "tartalom" => "Felhasználó regisztráció"],
    ["menu_id" => 1, "cim" => "Jelszó módosítás", "tartalom" => "Itt módosíthatod a jelszavad"],
    ["menu_id" => 2, "cim" => "Új jármű", "tartalom" => "Új jármű felvitele"],
    ["menu_id" => 2, "cim" => "Jármű lista", "tartalom" => "Meglévő járművek listája"],
    ["menu_id" => 3, "cim" => "Eladások", "tartalom" => "Eladások statisztikái"]
];

// Ha a menüpont nem létezik, állítsuk vissza az első elemre
if (!in_array($menupont, array_column($menu, 'id'))) {
    $menupont = 1;
}

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($menu[$menupont - 1]["title"]); ?></title>
    <link rel="stylesheet" href="./css/styles.css">
</head>
<body>

<nav>
    <?php
    foreach ($menu as $item) {
        $active = ($item["id"] == $menupont) ? "active" : "";
        echo "<a class='$active' href='?m=" . $item["id"] . "'>" . htmlspecialchars($item["nev"]) . "</a>";
    }
    ?>
    <a href="?logout=true" class="logout">Kilépés</a>
</nav>

<main>
    <?php
    foreach ($tartalom as $t) {
        if ($t["menu_id"] == $menupont) {
            echo "<h2>" . htmlspecialchars($t["cim"]) . "</h2>";
            echo "<p>" . htmlspecialchars($t["tartalom"]) . "</p>";
        }
    }
    ?>
</main>

</body>
</html>
