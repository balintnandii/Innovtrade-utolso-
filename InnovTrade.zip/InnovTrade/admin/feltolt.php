<?php
include('./includes/dbvezerlo.php');

$fnev = "admin";
$jelszo = "ujjelszo123"; // Itt add meg az új jelszót
$hash = password_hash($jelszo, PASSWORD_BCRYPT); // Jelszó biztonságos hash-elése

$dbvez = new DBVezerlo();
$query = "UPDATE admin SET passwd = ? WHERE fnev = ?";

if ($dbvez->executeQuery($query, [$hash, $fnev], "ss")) {
    echo "Admin jelszava frissítve!";
} else {
    echo "Hiba történt a frissítés során!";
}
?>