<?php
session_start();

if (!isset($_SESSION['kosar']) || count($_SESSION['kosar']) === 0) {
    echo "<p style='text-align:center;'>A kosár üres.</p>";
    exit;
}

echo "<ul id='also-kosar-lista' style='list-style: none; padding: 10px;'>";
foreach ($_SESSION['kosar'] as $index => $auto) {
    $nev = $auto['autonev'] ?? $auto['nev'] ?? 'Ismeretlen';
    echo "<li style='margin-bottom: 8px;'>"
       . htmlspecialchars($nev)
       . " <button class='also-torles' data-index='$index' style='margin-left:10px; background: none; border: none; color: red; cursor: pointer;'>❌</button>"
       . "</li>";
}
echo "</ul>";
?>
