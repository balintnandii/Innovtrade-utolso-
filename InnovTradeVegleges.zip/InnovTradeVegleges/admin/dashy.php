<?php
//session_start();
include('./includes/dbvezerlo.php');

if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

// Összes bevétel lekérdezése
$dbvez = new DBVezerlo();

// Teljes bevétel lekérdezése a bérelt napok és a jármű bérleti díja alapján
$query = "
    select sum(osszeg) as total_revenue 
    FROM foglalasok";
$result = $dbvez->executeSelectQuery($query, []);
//print_r($result);


$totalRevenue = $result[0]['total_revenue'] ?? 0;

// Éves bevételek lekérdezése a bérelt napok és a jármű bérleti díja alapján
$yearlyQuery = "
    SELECT 	YEAR(datum) as year, sum(osszeg) as yearly_revenue
    FROM foglalasok
    GROUP by YEAR(datum)";
$yearlyRevenueResult = $dbvez->executeSelectQuery($yearlyQuery, []);
//print_r($yearlyRevenueResult);
?>

<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js" defer></script>
    <title>Admin Dashboard</title>
</head>
<body>
<div class="stat-box">
  <h2>STAT</h2>
  <p>Teljes Bevétel: 5 947 000 Ft</p>
  <a href="#">Éves bevételek megtekintése</a>
</div>

    <div id="yearly-revenue" style="display: none;">
        <table class="stat-table">
            <thead>
                <tr>
                    <th>Év</th>
                    <th>Éves Bevétel</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($yearlyRevenueResult as $yearly) { ?>
                    <tr>
                        <td><?= htmlspecialchars($yearly['year']) ?></td>
                        <td><?= number_format($yearly['yearly_revenue'], 0, ',', ' ') ?> Ft</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>

