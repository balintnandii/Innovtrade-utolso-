<?php
session_start();
include('./includes/dbvezerlo.php');

if (isset($_POST['belep'])) {
    $email = $_POST['fnev'];
    $password = $_POST['passwd'];

    $dbvez = new DBVezerlo();

    $query = "SELECT fnev, passwd FROM admin WHERE fnev = ?";
    $eredmeny = $dbvez->executeSelectQuery($query, [$email], "s");

    if (!empty($eredmeny)) {
        $hashed_password = $eredmeny[0]['passwd'];

        if (password_verify($password, $hashed_password)) {
            $_SESSION['belepett'] = $email;
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<div class='alert'>Hibás jelszó</div>";
        }
    } else {
        echo "<div class='alert'>Hibás felhasználónév</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/styles.css">
  <title>Admin Belépés</title>
</head>
<body>
  <div class="admin-login">
    <h1>Belépés az adminfelületre</h1>
    <form method="post">
      <label for="fnev">Felhasználónév</label>
      <input type="text" name="fnev" placeholder="Felhasználónév" required>

      <label for="passwd">Jelszó</label>
      <input type="password" name="passwd" placeholder="Jelszó" required>

      <button type="submit" name="belep">BELÉPÉS</button>
    </form>
    <a href="/rozsamarcell/InnovTrade/index.php">⬅ Vissza a főoldalra</a>
  </div>
</body>
</html>