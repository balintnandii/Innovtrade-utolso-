<?php
session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

// Kilépés kezelése
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$menupont = 1;
if (isset($_GET['m']) && is_numeric($_GET['m'])) {
    $menupont = intval($_GET['m']);
}

// Menü definíció
$menu = [
    ["id" => 1, "nev" => "felhasználókezelés", "title" => "Felhasználó"],
    ["id" => 2, "nev" => "Járművek", "title" => "Jármű lista"],
    ["id" => 3, "nev" => "Eladások statisztika", "title" => "Eladások"]
];

// Tartalom definíció
$tartalom = [
    ["menu_id" => 1, "cim" => "Új felhasználó", "tartalom" => "Felhasználó regisztráció"],
    ["menu_id" => 1, "cim" => "Jelszó módosítás", "tartalom" => "jelszómódosítás"],
    ["menu_id" => 2, "cim" => "Új jármű", "tartalom" => "Új jármű felvitele"],
    ["menu_id" => 2, "cim" => "Jármű lista", "tartalom" => "Meglévő járművek listája"],
    ["menu_id" => 3, "cim" => "Eladások", "tartalom" => "Eladások statisztikái"],
    ["menu_id" => 3, "cim" => "Chartok", "tartalom" => "Chart"]
];

// Ha a menüpont nem létezik, állítsuk vissza az első elemre
if (!in_array($menupont, array_column($menu, 'id'))) {
    $menupont = 1;
}

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($menu[$menupont - 1]["title"]); ?></title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/jarmu_list.css">
    <link rel="stylesheet" href="css/ujjarmu.css">
</head>
<body>

<nav>
    <?php
    foreach ($menu as $item) {
        $active = ($item["id"] == $menupont) ? "active" : "";
        echo "<a class='$active' href='?m=" . $item["id"] . "'>" . htmlspecialchars($item["nev"]) . "</a>";
    }
    ?>
    <a href="?logout=true" class="logout">Kilépés</a>
</nav>

<main>
    <?php
    foreach ($tartalom as $t) {
        if ($t["menu_id"] == $menupont) {
            echo "<h2>" . htmlspecialchars($t["cim"]) . "</h2>";
            echo "<p>" . htmlspecialchars($t["tartalom"]) . "</p>";

            // Ha az "Új jármű" menü van kiválasztva, akkor jelenjen meg az űrlap
            if ($menupont == 2 && $t["cim"] == "Új jármű") {
                include('./ujjarmu.php');
            }

            // Ha a "Jármű lista" menü van kiválasztva, akkor jelenjenek meg a járművek
            if ($menupont == 2 && $t["cim"] == "Jármű lista") {
                include('./jarmuvek_lista.php');
            }
        }
    }
    ?>
</main>

</body>
</html>



