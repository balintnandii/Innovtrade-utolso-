<?php
header('Content-Type: application/json; charset=UTF-8');
session_start();
include 'db.php';

// POST-ból érkező adatok
$autoNev = $_POST['autonev'] ?? '';
$szoveg  = $_POST['szoveg']  ?? '';

// Hibás kérés esetén
if (!$autoNev || !$szoveg) {
    echo json_encode([
        'success' => false,
        'error'   => 'Hiányzó adatok: kérjük, válaszd ki az autót és írd meg a véleményt!'
    ]);
    exit;
}

// Bejelentkezett felhasználó ellenőrzése
$email = $_SESSION['email'] ?? '';
if (!$email) {
    echo json_encode([
        'success' => false,
        'error'   => 'Be kell jelentkezned a vélemény beküldéséhez!'
    ]);
    exit;
}

// Felhasználó ID lekérdezése email alapján
$stmt = $kapcsolat->prepare("SELECT id FROM felhasznalok WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($felhasznaloId);
if (!$stmt->fetch()) {
    echo json_encode([
        'success' => false,
        'error'   => 'Felhasználó nem található az adatbázisban!'
    ]);
    exit;
}
$stmt->close();

// Vélemény beszúrása
$stmt = $kapcsolat->prepare("
    INSERT INTO velemenyek (felhasznalo_id, auto_nev, szoveg)
    VALUES (?, ?, ?)
");
$stmt->bind_param("iss", $felhasznaloId, $autoNev, $szoveg);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode([
        'success' => false,
        'error'   => 'Adatbázis hiba: ' . $kapcsolat->error
    ]);
}

$stmt->close();
$kapcsolat->close();
