<?php
session_start();

if (!isset($_SESSION['2fa_email']) || !isset($_SESSION['2fa_code'])) {
    header("Location: index.php");
    exit();
}

$uzenet = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bekuldottKod = $_POST['kod'] ?? '';
    if ($bekuldottKod === $_SESSION['2fa_code']) {
        $_SESSION['belepett'] = $_SESSION['2fa_email'];
        unset($_SESSION['2fa_code']);
        unset($_SESSION['2fa_email']);
        header("Location: dashboard.php");
        exit();
    } else {
        $uzenet = "Hibás kód, kérlek próbáld újra!";
    }
}
?>

<h2>Hitelesítő kód megadása</h2>
<p>Kérlek add meg az e-mailben kapott hatjegyű kódot:</p>
<?php if ($uzenet): ?>
    <p style="color:red"><?= htmlspecialchars($uzenet) ?></p>
<?php endif; ?>
<form method="POST">
    <label for="kod">Kód:</label>
    <input type="text" name="kod" pattern="\d{6}" required>
    <button type="submit">Hitelesítés</button>
</form>
