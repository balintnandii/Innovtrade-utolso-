<?php
//session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}
include('includes/dbvezerlo.php');
$db = new DBVezerlo();

// Szűrők előkészítése
$statusFilter = "Status = 'könyvelt'";
if (!empty($_POST['include_pending'])) {
    $statusFilter = "Status IN ('könyvelt', 'feldolgoz')";
}

$fromDate = $_POST['from_date'] ?? '';
$toDate = $_POST['to_date'] ?? '';

$dateFilter = "1=1";
$params = [];
$types = "";

// Dátum szűrés
if (!empty($fromDate)) {
    $dateFilter .= " AND KezdDat >= ?";
    $params[] = $fromDate;
    $types .= "s";
}
if (!empty($toDate)) {
    $dateFilter .= " AND VegDat <= ?";
    $params[] = $toDate;
    $types .= "s";
}

// Lekérdezés az összes bevételhez
$query = "
    SELECT j.id, j.marka, j.evjarat, j.ar, COUNT(k.id) AS darabszam, 
    SUM(DATEDIFF(k.VegDat, k.KezdDat) + 1) * j.ar AS osszeg
    FROM jarmuvek j
    JOIN konyveles k ON j.id = k.jarmuAzon
    WHERE $statusFilter AND $dateFilter
    GROUP BY j.id
    ORDER BY osszeg DESC
";

$bevetelek = $db->executeSelectQuery($query, $params, $types);

// Alapértelmezett min és max dátumok
$minDate = '1970-01-01'; // Legkisebb dátum (1970.01.01)
$maxDate = date('Y-m-d', strtotime('+1 year')); // Max dátum (mai dátum + 1 év)
?>

<form method="POST">
    <label for="from_date">Dátumtól:</label>
    <!-- A min és max dátumok beállítása -->
    <input type="date" name="from_date" value="<?= htmlspecialchars($fromDate) ?: $minDate ?>" min="<?= $minDate ?>" max="<?= $maxDate ?>">

    <label for="to_date">Dátumig:</label>
    <input type="date" name="to_date" value="<?= htmlspecialchars($toDate) ?: $maxDate ?>" min="<?= $minDate ?>" max="<?= $maxDate ?>">

    <label>
        <input type="checkbox" name="include_pending" <?= isset($_POST['include_pending']) ? 'checked' : '' ?>>
        Feldolgozás alatt lévő tételek is
    </label>

    <button type="submit">Lekérdezés</button>
</form>

<?php if (!empty($bevetelek)): ?>
    <table>
        <thead>
            <tr>
                <th>Márka</th>
                <th>Évjárat</th>
                <th>Egységár (Ft)</th>
                <th>Eladások száma</th>
                <th>Összes bevétel (Ft)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bevetelek as $sor): ?>
                <tr>
                    <td><?= htmlspecialchars($sor['marka']) ?></td>
                    <td><?= htmlspecialchars($sor['evjarat']) ?></td>
                    <td><?= number_format($sor['ar'], 2, ',', ' ') ?></td>
                    <td><?= $sor['darabszam'] ?></td>
                    <td><?= number_format($sor['osszeg'], 2, ',', ' ') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Chart canvas -->
    <canvas id="bevetelChart" width="800" height="400"></canvas>

    <!-- Chart.js betöltése CDN-ről -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
    // PHP tömb JavaScript objektummá alakítása
    const chartData = <?= json_encode($bevetelek) ?>;

    // Adatok előkészítése: márka és bevétel
    const labels = chartData.map(item => item.marka);
    const values = chartData.map(item => parseFloat(item.osszeg));

    // Chart létrehozása
    const ctx = document.getElementById('bevetelChart').getContext('2d');
    const bevetelChart = new Chart(ctx, {
        type: 'bar', // Oszlopdiagram
        data: {
            labels: labels,
            datasets: [{
                label: 'Összes bevétel (Ft)',
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            // Forint formázás ezeres tagolással
                            return value.toLocaleString('hu-HU') + ' Ft';
                        }
                    }
                }
            }
        }
    });
    </script>
<?php else: ?>
    <p>Nincs megjeleníthető adat.</p>
<?php endif; ?>
