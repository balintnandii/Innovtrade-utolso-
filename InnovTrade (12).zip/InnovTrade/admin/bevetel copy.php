<?php
//session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}
include('includes/dbvezerlo.php');
$db = new DBVezerlo();

// Szűrők előkészítése
$statusFilter = "Status = 'könyvelt'";
if (!empty($_POST['include_pending'])) {
    $statusFilter = "Status IN ('könyvelt', 'feldolgoz')";
}

$fromDate = $_POST['from_date'] ?? '';
$toDate = $_POST['to_date'] ?? '';

$dateFilter = "1=1";
$params = [];
$types = "";

// Dátum szűrés
if (!empty($fromDate)) {
    $dateFilter .= " AND KezdDat >= ?";
    $params[] = $fromDate;
    $types .= "s";
}
if (!empty($toDate)) {
    $dateFilter .= " AND VegDat <= ?";
    $params[] = $toDate;
    $types .= "s";
}

// Lekérdezés összeállítása
$query = "
    SELECT j.id, j.marka, j.evjarat, j.ar, COUNT(k.id) AS darabszam, SUM(j.ar) AS osszeg
    FROM jarmuvek j
    JOIN konyveles k ON j.id = k.jarmuAzon
    WHERE $statusFilter AND $dateFilter
    GROUP BY j.id
    ORDER BY osszeg DESC
";

$bevetelek = $db->executeSelectQuery($query, $params, $types);
?>

<form method="POST">
    <label for="from_date">Dátumtól:</label>
    <input type="date" name="from_date" value="<?= htmlspecialchars($fromDate) ?>">

    <label for="to_date">Dátumig:</label>
    <input type="date" name="to_date" value="<?= htmlspecialchars($toDate) ?>">

    <label>
        <input type="checkbox" name="include_pending" <?= isset($_POST['include_pending']) ? 'checked' : '' ?>>
        Feldolgozás alatt lévő tételek is
    </label>

    <button type="submit">Lekérdezés</button>
</form>

<?php if (!empty($bevetelek)): ?>
    <table>
        <thead>
            <tr>
                <th>Márka</th>
                <th>Évjárat</th>
                <th>Egységár (Ft)</th>
                <th>Eladások száma</th>
                <th>Összes bevétel (Ft)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bevetelek as $sor): ?>
                <tr>
                    <td><?= htmlspecialchars($sor['marka']) ?></td>
                    <td><?= htmlspecialchars($sor['evjarat']) ?></td>
                    <td><?= number_format($sor['ar'], 2, ',', ' ') ?></td>
                    <td><?= $sor['darabszam'] ?></td>
                    <td><?= number_format($sor['osszeg'], 2, ',', ' ') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Nincs megjeleníthető adat.</p>
<?php endif; ?>
