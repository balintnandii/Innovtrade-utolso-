<?php
class teszt extends TestCase
{
    public function testSikeresBelepes()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo('helyesFelhasznalonev', 'helyesJelszo');
        $this->assertEquals(200, $valasz);
    }

    public function testHibasJelszo()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo('helyesFelhasznalonev', 'hibasJelszo');
        $this->assertEquals(403, $valasz);
    }

    public function testNemletezoFelhasznalo()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo('nemletezoFelhasznalo', 'barmi');
        $this->assertEquals(404, $valasz);
    }

    public function testUresAdatok()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo('', '');
        $this->assertEquals(400, $valasz);
    }

    public function testNagybetusFelhasznalonev()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo('HELYESFELHASZNALONEV', 'helyesJelszo');
        $this->assertEquals(200, $valasz); // Ha a bejelentkezés nem kis-nagybetű érzékeny
    }

    public function testTulHosszuJelszo()
    {
        require_once "teszt.php";
        $tulHosszuJelszo = str_repeat('a', 1000);
        $valasz = FelhasznaloNevJelszo('helyesFelhasznalonev', $tulHosszuJelszo);
        $this->assertEquals(403, $valasz);
    }

    public function testSqlInjectionProbalkozas()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo("'; DROP TABLE felhasznalok; --", 'barmi');
        $this->assertEquals(404, $valasz); // Tegyük fel, hogy nincs ilyen név
    }

    public function testSzokoztTartalmazoJelszo()
    {
        require_once "teszt.php";
        $valasz = FelhasznaloNevJelszo('helyesFelhasznalonev', ' helyesJelszo');
        $this->assertEquals(403, $valasz); // Szóköz miatt nem egyezik
    }
}
